from flask import Flask, request, jsonify, render_template
import subprocess
import tempfile
import os

app = Flask(__name__)

HTML_BOILERPLATE = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>HTML Preview</title>
</head>
<body>
{code}
</body>
</html>"""

CSS_BOILERPLATE = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>CSS Preview</title>
<style>
{code}
</style>
</head>
<body>
<h1>CSS Preview</h1>
<p>This is styled by your CSS code.</p>
</body>
</html>"""

JS_BOILERPLATE = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>JavaScript Preview</title>
</head>
<body>
<script>
try {{
{code}
}} catch(e) {{
  document.body.innerHTML = '<pre style="color:red;">' + e + '</pre>';
}}
</script>
</body>
</html>"""

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/run", methods=["POST"])
def run_code():
    data = request.json
    code = data.get("code", "")
    language = data.get("language", "html").lower()
    user_input = data.get("input", "")  # Get user input string (for Python)

    if language == "python":
        with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as f:
            f.write(code)
            f.flush()
            try:
                result = subprocess.run(
                    ["python", f.name],
                    input=user_input,              # <-- Pass user input here
                    capture_output=True,
                    text=True,
                    timeout=5
                )
                output = result.stdout + result.stderr
            except subprocess.TimeoutExpired:
                output = "Execution timed out."
            finally:
                os.remove(f.name)
        return jsonify({"output": f"<pre>{output}</pre>"})

    elif language == "html":
        output = HTML_BOILERPLATE.format(code=code)
        return jsonify({"output": output})

    elif language == "css":
        output = CSS_BOILERPLATE.format(code=code)
        return jsonify({"output": output})

    elif language == "javascript":
        output = JS_BOILERPLATE.format(code=code)
        return jsonify({"output": output})

    else:
        return jsonify({"output": "<pre>Unsupported language selected.</pre>"})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
